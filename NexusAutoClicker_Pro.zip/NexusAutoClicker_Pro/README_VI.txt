NEXUS AUTOCLICKER PRO - HIGH PRECISION EDITION
Windows 10/11 64-bit

Phim nong mac dinh:
- ` : bat/tat click (bam lai de dung)
- F7 : dung khan cap
- F8 : lay toa do con tro

Diem cai tien:
- Uu tien bo hen gio do phan giai cao cua Windows; tu dong dung co che du phong neu khong ho tro.
- Can chinh thoi diem bang QueryPerformanceCounter va bu sai so chia tan so, giam troi nhip o cac toc do khong chia het.
- Nang uu tien luong click len Above Normal trong luc chay.
- Giu cac tuy chon click, vi tri, so lan lap va phim nong nhu ban truoc.

Gioi han:
- Muc 2.000 click/giay la gioi han cai dat; khong dam bao ung dung dich se tiep nhan du tung su kien.
- Toc do thuc te phu thuoc Windows, CPU, quyen cua ung dung dich va cach ung dung xu ly su kien chuot.
- Nen thu o 250, 500, 800 va 1.000 CPS de tim muc on dinh tren may.
- Chua co may Windows thuc te trong moi truong nay de do CPS hoac kiem thu tuong tac GUI. Hay quet tep bang Microsoft Defender truoc khi chay.

Build tu ma nguon (can LLVM clang va lld-link):
Chay build_exe.bat trong thu muc nay tren Windows co LLVM tren PATH.
