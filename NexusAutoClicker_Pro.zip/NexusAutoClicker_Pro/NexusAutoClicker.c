/* Nexus AutoClicker - standalone native Windows application.
   Built as a PE32+ GUI executable with no Python or third-party runtime. */
#define WIN32_LEAN_AND_MEAN

typedef unsigned short WCHAR;
typedef WCHAR wchar_t;
typedef unsigned short WORD;
typedef unsigned long DWORD;
typedef long LONG;
typedef int BOOL;
typedef unsigned int UINT;
typedef unsigned long ULONG;
typedef unsigned long long ULONGLONG;
typedef unsigned long long ULONG_PTR;
typedef long long LONGLONG;
typedef unsigned long long SIZE_T;
typedef void *HANDLE;
typedef void *HWND;
typedef void *HINSTANCE;
typedef void *HHOOK;
typedef void *HMENU;
typedef void *HICON;
typedef void *HCURSOR;
typedef void *HBRUSH;
typedef void *HDC;
typedef void *LPVOID;
typedef const WCHAR *LPCWSTR;
typedef WCHAR *LPWSTR;
typedef ULONG_PTR WPARAM;
typedef long long LPARAM;
typedef long long LRESULT;
typedef LRESULT (__stdcall *WNDPROC)(HWND, UINT, WPARAM, LPARAM);
typedef LRESULT (__stdcall *HOOKPROC)(int, WPARAM, LPARAM);

typedef struct { LONG x; LONG y; } POINT;
typedef struct { LONG left; LONG top; LONG right; LONG bottom; } RECT;
typedef struct {
    HWND hwnd; UINT message; WPARAM wParam; LPARAM lParam;
    DWORD time; POINT pt;
} MSG;
typedef struct {
    UINT cbSize; UINT style; WNDPROC lpfnWndProc; int cbClsExtra; int cbWndExtra;
    HINSTANCE hInstance; HICON hIcon; HCURSOR hCursor; HBRUSH hbrBackground;
    LPCWSTR lpszMenuName; LPCWSTR lpszClassName; HICON hIconSm;
} WNDCLASSEXW;
typedef struct {
    POINT pt; DWORD mouseData; DWORD flags; DWORD time; ULONG_PTR dwExtraInfo;
} MSLLHOOKSTRUCT;
typedef struct {
    LONG dx; LONG dy; DWORD mouseData; DWORD dwFlags; DWORD time; ULONG_PTR dwExtraInfo;
} MOUSEINPUT;
typedef struct {
    DWORD type;
    union { MOUSEINPUT mi; } u;
} INPUT;

#define WINAPI __stdcall
#define CALLBACK __stdcall
#define TRUE 1
#define FALSE 0
#define NULL ((void*)0)
#define CW_USEDEFAULT ((int)0x80000000)
#define COLOR_WINDOW 5
#define IDI_APPLICATION ((LPCWSTR)32512)
#define IDC_ARROW ((LPCWSTR)32512)
#define WM_CREATE 0x0001
#define WM_DESTROY 0x0002
#define WM_CLOSE 0x0010
#define WM_COMMAND 0x0111
#define WM_HOTKEY 0x0312
#define WM_APP 0x8000
#define WM_APP_PICKED (WM_APP+1)
#define WM_APP_FINISHED (WM_APP+2)
#define WM_APP_STATUS (WM_APP+3)
#define SW_HIDE 0
#define SW_SHOW 5
#define SW_SHOWNORMAL 1
#define WS_OVERLAPPEDWINDOW 0x00CF0000L
#define WS_CAPTION 0x00C00000L
#define WS_SYSMENU 0x00080000L
#define WS_POPUP 0x80000000L
#define WS_CHILD 0x40000000L
#define WS_VISIBLE 0x10000000L
#define WS_TABSTOP 0x00010000L
#define WS_BORDER 0x00800000L
#define WS_VSCROLL 0x00200000L
#define WS_GROUP 0x00020000L
#define ES_NUMBER 0x2000L
#define ES_AUTOHSCROLL 0x0080L
#define BS_PUSHBUTTON 0x00000000L
#define BS_GROUPBOX 0x00000007L
#define BS_AUTORADIOBUTTON 0x00000009L
#define BS_AUTOCHECKBOX 0x00000003L
#define CBS_DROPDOWNLIST 0x0003L
#define CB_ADDSTRING 0x0143
#define CB_SETCURSEL 0x014E
#define CB_GETCURSEL 0x0147
#define BM_SETCHECK 0x00F1
#define BM_GETCHECK 0x00F0
#define BST_CHECKED 1
#define BN_CLICKED 0
#define SWP_NOSIZE 0x0001
#define SWP_NOMOVE 0x0002
#define SWP_NOZORDER 0x0004
#define MF_BYCOMMAND 0x0000
#define MB_OK 0x00000000L
#define MB_ICONINFORMATION 0x00000040L
#define MB_ICONWARNING 0x00000030L
#define MB_ICONERROR 0x00000010L
#define MB_YESNO 0x00000004L
#define IDYES 6
#define VK_F1 0x70
#define VK_F6 0x75
#define VK_F7 0x76
#define VK_F8 0x77
#define VK_OEM_3 0xC0 /* ` / ~ key */
#define MOD_ALT 0x0001
#define MOD_CONTROL 0x0002
#define MOD_SHIFT 0x0004
#define MOD_NOREPEAT 0x4000
#define WM_LBUTTONDOWN 0x0201
#define WM_LBUTTONUP 0x0202
#define WM_RBUTTONDOWN 0x0204
#define WM_RBUTTONUP 0x0205
#define WM_MBUTTONDOWN 0x0207
#define WM_MBUTTONUP 0x0208
#define WH_MOUSE_LL 14
#define HC_ACTION 0
#define LLMHF_INJECTED 0x00000001
#define INPUT_MOUSE 0
#define MOUSEEVENTF_LEFTDOWN 0x0002
#define MOUSEEVENTF_LEFTUP 0x0004
#define MOUSEEVENTF_RIGHTDOWN 0x0008
#define MOUSEEVENTF_RIGHTUP 0x0010
#define MOUSEEVENTF_MIDDLEDOWN 0x0020
#define MOUSEEVENTF_MIDDLEUP 0x0040
#define WAIT_OBJECT_0 0
#define INFINITE 0xFFFFFFFF
#define CREATE_WAITABLE_TIMER_HIGH_RESOLUTION 0x00000002
#define TIMER_ALL_ACCESS 0x001F0003
#define THREAD_PRIORITY_ABOVE_NORMAL 1

/* Win32 API imports. */
extern __declspec(dllimport) HINSTANCE WINAPI GetModuleHandleW(LPCWSTR);
extern __declspec(dllimport) HANDLE WINAPI CreateThread(void*, SIZE_T, DWORD (WINAPI *)(LPVOID), LPVOID, DWORD, DWORD*);
extern __declspec(dllimport) BOOL WINAPI CloseHandle(HANDLE);
extern __declspec(dllimport) DWORD WINAPI WaitForSingleObject(HANDLE, DWORD);
extern __declspec(dllimport) void WINAPI Sleep(DWORD);
extern __declspec(dllimport) HANDLE WINAPI GetCurrentThread(void);
extern __declspec(dllimport) BOOL WINAPI SetThreadPriority(HANDLE, int);
extern __declspec(dllimport) HANDLE WINAPI CreateWaitableTimerExW(void*, LPCWSTR, DWORD, DWORD);
extern __declspec(dllimport) BOOL WINAPI SetWaitableTimer(HANDLE, const LONGLONG*, LONG, void*, void*, BOOL);
extern __declspec(dllimport) BOOL WINAPI QueryPerformanceCounter(LONGLONG*);
extern __declspec(dllimport) BOOL WINAPI QueryPerformanceFrequency(LONGLONG*);
/* Use an inline atomic exchange; avoids importing InterlockedExchange from kernel32. */
#define InterlockedExchange(Target, Value) __atomic_exchange_n((Target), (Value), __ATOMIC_SEQ_CST)
extern __declspec(dllimport) DWORD WINAPI GetTickCount(void);
extern __declspec(dllimport) void WINAPI ExitProcess(UINT);

extern __declspec(dllimport) unsigned short WINAPI RegisterClassExW(const WNDCLASSEXW*);
extern __declspec(dllimport) HWND WINAPI CreateWindowExW(DWORD, LPCWSTR, LPCWSTR, DWORD, int, int, int, int, HWND, HMENU, HINSTANCE, LPVOID);
extern __declspec(dllimport) LRESULT WINAPI DefWindowProcW(HWND, UINT, WPARAM, LPARAM);
extern __declspec(dllimport) BOOL WINAPI ShowWindow(HWND, int);
extern __declspec(dllimport) BOOL WINAPI UpdateWindow(HWND);
extern __declspec(dllimport) BOOL WINAPI GetMessageW(MSG*, HWND, UINT, UINT);
extern __declspec(dllimport) BOOL WINAPI TranslateMessage(const MSG*);
extern __declspec(dllimport) LRESULT WINAPI DispatchMessageW(const MSG*);
extern __declspec(dllimport) void WINAPI PostQuitMessage(int);
extern __declspec(dllimport) HCURSOR WINAPI LoadCursorW(HINSTANCE, LPCWSTR);
extern __declspec(dllimport) BOOL WINAPI RegisterHotKey(HWND, int, UINT, UINT);
extern __declspec(dllimport) BOOL WINAPI UnregisterHotKey(HWND, int);
extern __declspec(dllimport) LRESULT WINAPI SendMessageW(HWND, UINT, WPARAM, LPARAM);
extern __declspec(dllimport) BOOL WINAPI SetWindowTextW(HWND, LPCWSTR);
extern __declspec(dllimport) int WINAPI GetWindowTextW(HWND, LPWSTR, int);
extern __declspec(dllimport) int WINAPI MessageBoxW(HWND, LPCWSTR, LPCWSTR, UINT);
extern __declspec(dllimport) BOOL WINAPI GetCursorPos(POINT*);
extern __declspec(dllimport) BOOL WINAPI SetCursorPos(int, int);
extern __declspec(dllimport) UINT WINAPI SendInput(UINT, INPUT*, int);
extern __declspec(dllimport) HHOOK WINAPI SetWindowsHookExW(int, HOOKPROC, HINSTANCE, DWORD);
extern __declspec(dllimport) BOOL WINAPI UnhookWindowsHookEx(HHOOK);
extern __declspec(dllimport) LRESULT WINAPI CallNextHookEx(HHOOK, int, WPARAM, LPARAM);
extern __declspec(dllimport) BOOL WINAPI PostMessageW(HWND, UINT, WPARAM, LPARAM);
extern __declspec(dllimport) BOOL WINAPI EnableWindow(HWND, BOOL);
extern __declspec(dllimport) HWND WINAPI GetDlgItem(HWND, int);
extern __declspec(dllimport) BOOL WINAPI DestroyWindow(HWND);
extern __declspec(dllimport) BOOL WINAPI SetForegroundWindow(HWND);
extern __declspec(dllimport) UINT WINAPI timeBeginPeriod(UINT);
extern __declspec(dllimport) UINT WINAPI timeEndPeriod(UINT);

#define MAIN_CLASS L"NexusAutoClickerMain"
#define HOT_CLASS L"NexusAutoClickerHotkey"
#define ID_BUTTON 1001
#define ID_TYPE 1002
#define ID_REPEAT_COUNT 1003
#define ID_REPEAT_FOREVER 1004
#define ID_COUNT 1005
#define ID_SPEED 1006
#define ID_CURRENT 1101
#define ID_FIXED 1102
#define ID_PICK 1103
#define ID_X 1104
#define ID_Y 1105
#define ID_START 1201
#define ID_STOP 1202
#define ID_HOTKEY 1203
#define ID_RECORD 1204
#define ID_STATUS 1205
#define ID_HOT_SAVE 6001
#define ID_HOT_CANCEL 6002
#define ID_HOT_KEY 6003
#define ID_HOT_CTRL 6004
#define ID_HOT_ALT 6005
#define ID_HOT_SHIFT 6006
#define HOT_TOGGLE 1
#define HOT_STOP 2
#define HOT_CAPTURE 3
#define MAX_EVENTS 60000

static HINSTANCE g_inst;
static HWND g_main;
static HWND g_button, g_type, g_repeatCount, g_repeatForever, g_count, g_speed;
static HWND g_current, g_fixed, g_pick, g_x, g_y, g_start, g_stop, g_hotButton, g_recordButton, g_status;
static HWND g_hotWindow;
static HANDLE g_worker;
static volatile LONG g_running = 0;
static volatile LONG g_mode = 0; /* 0 idle, 1 click thread, 2 playback thread */
static int g_hotVk = VK_OEM_3; /* ` toggles start/stop */
static UINT g_hotMods = 0;
static int g_recordState = 0; /* 0 ready-to-record, 1 recording, 2 recorded, 3 playback */
static HHOOK g_mouseHook;
static int g_hookKind = 0; /* 1 recording, 2 position picker */
static int g_pickX, g_pickY;
static int g_pickPending = 0;
static volatile LONG g_eventCount = 0;

typedef struct { DWORD tick; LONG x; LONG y; DWORD flags; } REC_EVENT;
static REC_EVENT g_events[MAX_EVENTS];

static void setText(HWND h, LPCWSTR s) { if (h) SetWindowTextW(h, s); }
static void status(LPCWSTR s) { setText(g_status, s); }
static void intToText(int n, WCHAR *out) {
    WCHAR tmp[20]; int i=0, j=0; unsigned int v;
    if (n < 0) { out[j++]='-'; v=(unsigned int)(-n); } else v=(unsigned int)n;
    if (v==0) tmp[i++]='0';
    while (v && i<18) { tmp[i++]=(WCHAR)('0'+(v%10)); v/=10; }
    while (i>0) out[j++]=tmp[--i]; out[j]=0;
}
static int parseText(HWND h, int fallback) {
    WCHAR b[32]; int n=0, i=0; GetWindowTextW(h,b,31);
    while (b[i]==' ' || b[i]=='\t') i++;
    if (b[i]==0) return fallback;
    while (b[i]>='0' && b[i]<='9') { n=n*10+(b[i]-'0'); if (n>2000000000) return 2000000000; i++; }
    return n;
}
static void setInt(HWND h, int n) { WCHAR b[24]; intToText(n,b); setText(h,b); }
static HWND ctl(LPCWSTR cls, LPCWSTR label, DWORD style, int x, int y, int w, int h, int id) {
    return CreateWindowExW(0,cls,label,WS_CHILD|WS_VISIBLE|style,x,y,w,h,g_main,(HMENU)(ULONG_PTR)id,g_inst,0);
}
static void check(HWND h, int value) { SendMessageW(h,BM_SETCHECK,(WPARAM)(value?BST_CHECKED:0),0); }
static int isChecked(HWND h) { return SendMessageW(h,BM_GETCHECK,0,0)==BST_CHECKED; }
static void setXY(int x, int y) { setInt(g_x,x); setInt(g_y,y); }
static void appendWide(WCHAR *out, int *p, LPCWSTR src) {
    int i=0; while (src[i]) { out[*p]=src[i]; (*p)++; i++; }
}
static void hotkeyName(WCHAR *out) {
    int p=0, n=g_hotVk-VK_F1+1;
    if (g_hotVk==VK_OEM_3) { appendWide(out,&p,L"`"); out[p]=0; return; }
    if (g_hotMods&MOD_CONTROL) appendWide(out,&p,L"Ctrl+");
    if (g_hotMods&MOD_ALT) appendWide(out,&p,L"Alt+");
    if (g_hotMods&MOD_SHIFT) appendWide(out,&p,L"Shift+");
    out[p++]='F';
    if (n>=10) out[p++]=(WCHAR)('0'+n/10);
    out[p++]=(WCHAR)('0'+n%10);
    out[p]=0;
}
static void updateRunButtons(int running) {
    WCHAR b[80], key[32]; int p=0; hotkeyName(key);
    if (running) appendWide(b,&p,L"Đang chạy - ");
    else appendWide(b,&p,L"Bắt đầu (");
    appendWide(b,&p,key);
    if (running) appendWide(b,&p,L" để dừng");
    else appendWide(b,&p,L")");
    b[p]=0; setText(g_start,b);
}
static void closeWorkerHandle(void) {
    if (g_worker) { CloseHandle(g_worker); g_worker=0; }
}
static void stopClicking(void) { InterlockedExchange(&g_running,0); }
static void waitUntil(LONGLONG target, LONGLONG freq, HANDLE timer) {
    LONGLONG now=0;
    for (;;) {
        if (!g_running) return;
        QueryPerformanceCounter(&now);
        if (now>=target) return;
        LONGLONG left=target-now;
        if (timer && left>freq/10000) {
            /* High-resolution waitable timer: negative value is a relative due time in 100 ns. */
            LONGLONG due=-((left*10000000LL)/freq);
            if (due==0) due=-1;
            if (SetWaitableTimer(timer,&due,0,0,0,FALSE)) {
                WaitForSingleObject(timer,5); /* Poll briefly so F7 remains responsive. */
                continue; /* Check QPC again; timer wake-ups can be early. */
            }
        }
        /* Fallback (or final 0.1 ms): precise short spin avoids Sleep(0) scheduler yields. */
        if (!timer && left>freq/1000) {
            Sleep(1);
        } else {
            do {
                if (!g_running) return;
                QueryPerformanceCounter(&now);
            } while (now<target);
            return;
        }
    }
}
static DWORD WINAPI clickThread(LPVOID unused) {
    (void)unused;
    /* Worker settings are stored in static snapshot variables before thread creation. */
    extern int g_runButton, g_runClickType, g_runLimit, g_runForever, g_runSpeed, g_runFixed, g_runX, g_runY;
    int down= MOUSEEVENTF_LEFTDOWN, up=MOUSEEVENTF_LEFTUP;
    if (g_runButton==1) { down=MOUSEEVENTF_RIGHTDOWN; up=MOUSEEVENTF_RIGHTUP; }
    if (g_runButton==2) { down=MOUSEEVENTF_MIDDLEDOWN; up=MOUSEEVENTF_MIDDLEUP; }
    LONGLONG freq=0, next=0, now=0;
    QueryPerformanceFrequency(&freq); if (freq<=0) freq=1000000;
    HANDLE timer=CreateWaitableTimerExW(0,0,CREATE_WAITABLE_TIMER_HIGH_RESOLUTION,TIMER_ALL_ACCESS);
    if (!timer) timeBeginPeriod(1);
    SetThreadPriority(GetCurrentThread(),THREAD_PRIORITY_ABOVE_NORMAL);
    int cycles=0;
    LONGLONG step=freq/(g_runSpeed>0?g_runSpeed:1);
    LONGLONG remainder=freq%(g_runSpeed>0?g_runSpeed:1);
    LONGLONG remainderAcc=0;
    if (step<1) step=1;
    while (g_running && (g_runForever || cycles<g_runLimit)) {
        for (int k=0;k<g_runClickType && g_running;k++) {
            if (g_runFixed) SetCursorPos(g_runX,g_runY);
            INPUT in[2];
            in[0].type=INPUT_MOUSE; in[0].u.mi.dx=0; in[0].u.mi.dy=0; in[0].u.mi.mouseData=0; in[0].u.mi.dwFlags=(DWORD)down; in[0].u.mi.time=0; in[0].u.mi.dwExtraInfo=0;
            in[1].type=INPUT_MOUSE; in[1].u.mi.dx=0; in[1].u.mi.dy=0; in[1].u.mi.mouseData=0; in[1].u.mi.dwFlags=(DWORD)up; in[1].u.mi.time=0; in[1].u.mi.dwExtraInfo=0;
            if (SendInput(2,in,sizeof(INPUT))!=2) { InterlockedExchange(&g_running,0); PostMessageW(g_main,WM_APP_STATUS,0,(LPARAM)L"Windows không nhận đủ sự kiện click. Hãy thử chạy cùng quyền với ứng dụng đích."); break; }
            QueryPerformanceCounter(&now);
            if (next==0 || next<now) next=now;
            next += step;
            remainderAcc += remainder;
            if (remainderAcc >= (g_runSpeed>0?g_runSpeed:1)) {
                next++;
                remainderAcc -= (g_runSpeed>0?g_runSpeed:1);
            }
            waitUntil(next,freq,timer);
        }
        cycles++;
    }
    if (timer) CloseHandle(timer);
    else timeEndPeriod(1);
    InterlockedExchange(&g_running,0);
    PostMessageW(g_main,WM_APP_FINISHED,1,0);
    return 0;
}
int g_runButton=0, g_runClickType=1, g_runLimit=1, g_runForever=0, g_runSpeed=250, g_runFixed=0, g_runX=0, g_runY=0;

static void waitMillis(DWORD ms) {
    while (ms>0 && g_running) { DWORD part=ms>10?10:ms; Sleep(part); ms-=part; }
}
static DWORD WINAPI playbackThread(LPVOID unused) {
    (void)unused;
    int count=(int)g_eventCount;
    DWORD previous=0;
    for (int i=0;i<count && g_running;i++) {
        REC_EVENT e=g_events[i];
        if (i>0) waitMillis(e.tick-previous);
        previous=e.tick;
        if (!g_running) break;
        SetCursorPos((int)e.x,(int)e.y);
        INPUT in; in.type=INPUT_MOUSE; in.u.mi.dx=0; in.u.mi.dy=0; in.u.mi.mouseData=0; in.u.mi.dwFlags=e.flags; in.u.mi.time=0; in.u.mi.dwExtraInfo=0;
        SendInput(1,&in,sizeof(INPUT));
    }
    InterlockedExchange(&g_running,0);
    PostMessageW(g_main,WM_APP_FINISHED,2,0);
    return 0;
}
static DWORD mouseFlag(WPARAM msg) {
    if (msg==WM_LBUTTONDOWN) return MOUSEEVENTF_LEFTDOWN;
    if (msg==WM_LBUTTONUP) return MOUSEEVENTF_LEFTUP;
    if (msg==WM_RBUTTONDOWN) return MOUSEEVENTF_RIGHTDOWN;
    if (msg==WM_RBUTTONUP) return MOUSEEVENTF_RIGHTUP;
    if (msg==WM_MBUTTONDOWN) return MOUSEEVENTF_MIDDLEDOWN;
    if (msg==WM_MBUTTONUP) return MOUSEEVENTF_MIDDLEUP;
    return 0;
}
static LRESULT CALLBACK lowMouseProc(int code, WPARAM msg, LPARAM lp) {
    if (code==HC_ACTION && g_hookKind) {
        MSLLHOOKSTRUCT *m=(MSLLHOOKSTRUCT*)lp;
        if (g_hookKind==2 && !(m->flags&LLMHF_INJECTED) && msg==WM_LBUTTONDOWN && !g_pickPending) {
            g_pickX=(int)m->pt.x; g_pickY=(int)m->pt.y; g_pickPending=1;
            return 1;
        }
        if (g_hookKind==2 && !(m->flags&LLMHF_INJECTED) && msg==WM_LBUTTONUP && g_pickPending) {
            g_hookKind=0; g_pickPending=0;
            if (g_mouseHook) { UnhookWindowsHookEx(g_mouseHook); g_mouseHook=0; }
            PostMessageW(g_main,WM_APP_PICKED,0,0);
            return 1;
        }
        if (g_hookKind==1 && !(m->flags&LLMHF_INJECTED)) {
            DWORD f=mouseFlag(msg);
            if (f) {
                LONG idx=InterlockedExchange(&g_eventCount,g_eventCount+1);
                if (idx>=0 && idx<MAX_EVENTS) {
                    g_events[idx].tick=GetTickCount(); g_events[idx].x=m->pt.x; g_events[idx].y=m->pt.y; g_events[idx].flags=f;
                } else { InterlockedExchange(&g_eventCount,MAX_EVENTS); }
            }
        }
    }
    return CallNextHookEx(g_mouseHook,code,msg,lp);
}
static void startPick(void) {
    if (g_hookKind || g_mouseHook) return;
    if (g_running) stopClicking();
    g_pickPending=0; g_hookKind=2; g_mouseHook=SetWindowsHookExW(WH_MOUSE_LL,lowMouseProc,g_inst,0);
    if (!g_mouseHook) { g_hookKind=0; MessageBoxW(g_main,L"Không thể bật chế độ chọn tọa độ.",L"Nexus AutoClicker",MB_OK|MB_ICONERROR); return; }
    status(L"Hãy nhấp vào vị trí muốn click trên màn hình...");
    ShowWindow(g_main,SW_HIDE);
}
static void startRecording(void) {
    if (g_hookKind || g_mouseHook) return;
    InterlockedExchange(&g_eventCount,0);
    g_hookKind=1; g_mouseHook=SetWindowsHookExW(WH_MOUSE_LL,lowMouseProc,g_inst,0);
    if (!g_mouseHook) { g_hookKind=0; MessageBoxW(g_main,L"Không thể bắt đầu ghi thao tác chuột.",L"Nexus AutoClicker",MB_OK|MB_ICONERROR); return; }
    g_recordState=1; setText(g_recordButton,L"Dừng ghi"); status(L"Đang ghi thao tác chuột... Nhấn 'Dừng ghi' để kết thúc.");
}
static void stopRecording(void) {
    g_hookKind=0; if (g_mouseHook) { UnhookWindowsHookEx(g_mouseHook); g_mouseHook=0; }
    g_recordState=2; setText(g_recordButton,L"Phát lại thao tác");
    status(L"Đã lưu thao tác chuột. Nhấn 'Phát lại thao tác' để chạy lại.");
}
static void startClicking(void) {
    if (g_worker || g_running) { stopClicking(); status(L"Đang dừng click..."); return; }
    g_runButton=(int)SendMessageW(g_button,CB_GETCURSEL,0,0); if (g_runButton<0) g_runButton=0;
    g_runClickType=(int)SendMessageW(g_type,CB_GETCURSEL,0,0)+1; if (g_runClickType<1 || g_runClickType>3) g_runClickType=1;
    g_runForever=isChecked(g_repeatForever);
    g_runLimit=parseText(g_count,1); if (g_runLimit<1) g_runLimit=1; if (g_runLimit>2000000000) g_runLimit=2000000000;
    g_runSpeed=parseText(g_speed,250); if (g_runSpeed<1) g_runSpeed=1; if (g_runSpeed>2000) g_runSpeed=2000; setInt(g_speed,g_runSpeed);
    g_runFixed=isChecked(g_fixed); g_runX=parseText(g_x,0); g_runY=parseText(g_y,0);
    InterlockedExchange(&g_running,1); g_mode=1; updateRunButtons(1); status(L"Đang click. Nhấn ` lần nữa để kết thúc; F7 cũng dừng.");
    g_worker=CreateThread(0,0,clickThread,0,0,0);
    if (!g_worker) { InterlockedExchange(&g_running,0); updateRunButtons(0); status(L"Không tạo được luồng click."); MessageBoxW(g_main,L"Không tạo được luồng chạy click.",L"Lỗi",MB_OK|MB_ICONERROR); }
}
static void startPlayback(void) {
    if (g_worker || g_running) return;
    if (g_eventCount<=0) { MessageBoxW(g_main,L"Chưa có thao tác nào được ghi.",L"Nexus AutoClicker",MB_OK|MB_ICONINFORMATION); return; }
    InterlockedExchange(&g_running,1); g_mode=2; g_recordState=3; setText(g_recordButton,L"Đang phát lại..."); status(L"Đang phát lại thao tác chuột. Nhấn F7 để dừng.");
    g_worker=CreateThread(0,0,playbackThread,0,0,0);
    if (!g_worker) { InterlockedExchange(&g_running,0); g_mode=0; setText(g_recordButton,L"Phát lại thao tác"); status(L"Không tạo được luồng phát lại."); }
}
static void openHotDialog(void);

static LRESULT CALLBACK hotProc(HWND w, UINT msg, WPARAM wp, LPARAM lp) {
    if (msg==WM_CREATE) {
        CreateWindowExW(0,L"STATIC",L"Phím ` dùng để bắt đầu và nhấn lần nữa để kết thúc:",WS_CHILD|WS_VISIBLE,18,16,300,22,w,0,g_inst,0);
        CreateWindowExW(0,L"BUTTON",L"Ctrl",WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_AUTOCHECKBOX,20,52,65,24,w,(HMENU)(ULONG_PTR)ID_HOT_CTRL,g_inst,0);
        CreateWindowExW(0,L"BUTTON",L"Alt",WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_AUTOCHECKBOX,95,52,65,24,w,(HMENU)(ULONG_PTR)ID_HOT_ALT,g_inst,0);
        CreateWindowExW(0,L"BUTTON",L"Shift",WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_AUTOCHECKBOX,170,52,75,24,w,(HMENU)(ULONG_PTR)ID_HOT_SHIFT,g_inst,0);
        CreateWindowExW(0,L"STATIC",L"Phím:",WS_CHILD|WS_VISIBLE,20,91,65,22,w,0,g_inst,0);
        HWND combo=CreateWindowExW(0,L"COMBOBOX",L"",WS_CHILD|WS_VISIBLE|WS_TABSTOP|CBS_DROPDOWNLIST,85,87,110,180,w,(HMENU)(ULONG_PTR)ID_HOT_KEY,g_inst,0);
        SendMessageW(combo,CB_ADDSTRING,0,(LPARAM)L"` (Backtick)");
        for (int i=1;i<=12;i++) { WCHAR b[5]={ 'F',(WCHAR)('0'+i/10),(WCHAR)('0'+i%10),0,0 }; if (i<10) { b[1]=(WCHAR)('0'+i); b[2]=0; } SendMessageW(combo,CB_ADDSTRING,0,(LPARAM)b); }
        SendMessageW(combo,CB_SETCURSEL,(WPARAM)(g_hotVk==VK_OEM_3?0:(g_hotVk-VK_F1+1)),0);
        if (g_hotMods&MOD_CONTROL) SendMessageW(GetDlgItem(w,ID_HOT_CTRL),BM_SETCHECK,BST_CHECKED,0);
        if (g_hotMods&MOD_ALT) SendMessageW(GetDlgItem(w,ID_HOT_ALT),BM_SETCHECK,BST_CHECKED,0);
        if (g_hotMods&MOD_SHIFT) SendMessageW(GetDlgItem(w,ID_HOT_SHIFT),BM_SETCHECK,BST_CHECKED,0);
        CreateWindowExW(0,L"BUTTON",L"Lưu",WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_PUSHBUTTON,72,135,90,30,w,(HMENU)(ULONG_PTR)ID_HOT_SAVE,g_inst,0);
        CreateWindowExW(0,L"BUTTON",L"Hủy",WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_PUSHBUTTON,177,135,90,30,w,(HMENU)(ULONG_PTR)ID_HOT_CANCEL,g_inst,0);
        return 0;
    }
    if (msg==WM_COMMAND) {
        int id=(int)(wp&0xffff);
        if (id==ID_HOT_SAVE) {
            HWND c=(HWND)0; (void)c;
            HWND combo=0;
            /* Find the combo by re-querying the dialog child control through its ID helper. */
            combo=GetDlgItem(w,ID_HOT_KEY);
            int sel=(int)SendMessageW(combo,CB_GETCURSEL,0,0); if (sel<0) sel=5;
            UINT mods=0;
            if (SendMessageW(GetDlgItem(w,ID_HOT_CTRL),BM_GETCHECK,0,0)==BST_CHECKED) mods|=MOD_CONTROL;
            if (SendMessageW(GetDlgItem(w,ID_HOT_ALT),BM_GETCHECK,0,0)==BST_CHECKED) mods|=MOD_ALT;
            if (SendMessageW(GetDlgItem(w,ID_HOT_SHIFT),BM_GETCHECK,0,0)==BST_CHECKED) mods|=MOD_SHIFT;
            int newVk=(sel==0?VK_OEM_3:VK_F1+sel-1);
            if (mods==0 && (newVk==VK_F7 || newVk==VK_F8)) {
                MessageBoxW(w,L"F7 và F8 đang dành cho chức năng Dừng và Lấy tọa độ. Hãy chọn phím khác hoặc thêm Ctrl/Alt/Shift.",L"Phím đã được sử dụng",MB_OK|MB_ICONWARNING);
                return 0;
            }
            UnregisterHotKey(g_main,HOT_TOGGLE);
            if (!RegisterHotKey(g_main,HOT_TOGGLE,mods|MOD_NOREPEAT,(UINT)newVk)) {
                RegisterHotKey(g_main,HOT_TOGGLE,g_hotMods|MOD_NOREPEAT,(UINT)g_hotVk);
                MessageBoxW(w,L"Tổ hợp phím này đang được ứng dụng khác sử dụng. Hãy chọn tổ hợp khác.",L"Không thể đăng ký phím nóng",MB_OK|MB_ICONWARNING);
                return 0;
            }
            g_hotVk=newVk; g_hotMods=mods;
            updateRunButtons(g_running!=0);
            status(L"Đã lưu phím bật/tắt mới. F7 vẫn dừng, F8 vẫn lấy tọa độ.");
            DestroyWindow(w); return 0;
        }
        if (id==ID_HOT_CANCEL) { DestroyWindow(w); return 0; }
    }
    if (msg==WM_CLOSE) { DestroyWindow(w); return 0; }
    if (msg==WM_DESTROY) { g_hotWindow=0; EnableWindow(g_main,TRUE); SetForegroundWindow(g_main); return 0; }
    return DefWindowProcW(w,msg,wp,lp);
}
static void openHotDialog(void) {
    if (g_hotWindow) return;
    g_hotWindow=CreateWindowExW(0x00000001L,HOT_CLASS,L"Cài đặt phím nóng",WS_CAPTION|WS_SYSMENU|WS_POPUP,0,0,340,220,g_main,0,g_inst,0);
    if (g_hotWindow) { EnableWindow(g_main,FALSE); ShowWindow(g_hotWindow,SW_SHOW); SetForegroundWindow(g_hotWindow); }
}

static LRESULT CALLBACK mainProc(HWND w, UINT msg, WPARAM wp, LPARAM lp) {
    if (msg==WM_CREATE) {
        g_main=w;
        ctl(L"BUTTON",L"Tùy chọn click",BS_GROUPBOX,10,8,292,125,0);
        ctl(L"STATIC",L"Nút chuột:",0,24,33,90,22,0);
        g_button=ctl(L"COMBOBOX",L"",CBS_DROPDOWNLIST|WS_VSCROLL|WS_TABSTOP,120,29,155,100,ID_BUTTON);
        SendMessageW(g_button,CB_ADDSTRING,0,(LPARAM)L"Trái"); SendMessageW(g_button,CB_ADDSTRING,0,(LPARAM)L"Phải"); SendMessageW(g_button,CB_ADDSTRING,0,(LPARAM)L"Giữa"); SendMessageW(g_button,CB_SETCURSEL,0,0);
        ctl(L"STATIC",L"Kiểu click:",0,24,73,90,22,0);
        g_type=ctl(L"COMBOBOX",L"",CBS_DROPDOWNLIST|WS_VSCROLL|WS_TABSTOP,120,69,155,100,ID_TYPE);
        SendMessageW(g_type,CB_ADDSTRING,0,(LPARAM)L"1 lần"); SendMessageW(g_type,CB_ADDSTRING,0,(LPARAM)L"2 lần"); SendMessageW(g_type,CB_ADDSTRING,0,(LPARAM)L"3 lần"); SendMessageW(g_type,CB_SETCURSEL,0,0);

        ctl(L"BUTTON",L"Lặp lại",BS_GROUPBOX,315,8,300,125,0);
        g_repeatCount=ctl(L"BUTTON",L"Lặp số lần",BS_AUTORADIOBUTTON|WS_GROUP|WS_TABSTOP,329,29,105,24,ID_REPEAT_COUNT);
        check(g_repeatCount,1);
        g_count=ctl(L"EDIT",L"100",WS_BORDER|ES_NUMBER|ES_AUTOHSCROLL|WS_TABSTOP,438,29,65,24,ID_COUNT);
        ctl(L"STATIC",L"lần",0,510,32,38,20,0);
        g_repeatForever=ctl(L"BUTTON",L"Lặp đến khi dừng",BS_AUTORADIOBUTTON|WS_TABSTOP,329,58,160,24,ID_REPEAT_FOREVER);
        ctl(L"STATIC",L"Tốc độ (click/giây):",0,329,91,130,22,0);
        g_speed=ctl(L"EDIT",L"250",WS_BORDER|ES_NUMBER|ES_AUTOHSCROLL|WS_TABSTOP,464,87,65,24,ID_SPEED);
        ctl(L"STATIC",L"(tối đa 2.000)",0,534,91,75,22,0);

        ctl(L"BUTTON",L"Vị trí con trỏ",BS_GROUPBOX,10,143,605,105,0);
        g_current=ctl(L"BUTTON",L"Vị trí hiện tại",BS_AUTORADIOBUTTON|WS_GROUP|WS_TABSTOP,24,166,145,24,ID_CURRENT); check(g_current,1);
        g_fixed=ctl(L"BUTTON",L"Tọa độ cố định",BS_AUTORADIOBUTTON|WS_TABSTOP,184,166,145,24,ID_FIXED);
        g_pick=ctl(L"BUTTON",L"Chọn vị trí...",BS_PUSHBUTTON|WS_TABSTOP,354,161,125,30,ID_PICK);
        ctl(L"STATIC",L"X:",0,190,204,18,22,0); g_x=ctl(L"EDIT",L"0",WS_BORDER|ES_NUMBER|ES_AUTOHSCROLL|WS_TABSTOP,211,199,70,24,ID_X);
        ctl(L"STATIC",L"Y:",0,300,204,18,22,0); g_y=ctl(L"EDIT",L"0",WS_BORDER|ES_NUMBER|ES_AUTOHSCROLL|WS_TABSTOP,321,199,70,24,ID_Y);

        g_start=ctl(L"BUTTON",L"Bắt đầu (`)",BS_PUSHBUTTON|WS_TABSTOP,15,263,285,45,ID_START);
        g_stop=ctl(L"BUTTON",L"Dừng ngay (F7)",BS_PUSHBUTTON|WS_TABSTOP,315,263,285,45,ID_STOP);
        g_hotButton=ctl(L"BUTTON",L"Cài đặt phím nóng",BS_PUSHBUTTON|WS_TABSTOP,15,320,285,43,ID_HOTKEY);
        g_recordButton=ctl(L"BUTTON",L"Record & Playback",BS_PUSHBUTTON|WS_TABSTOP,315,320,285,43,ID_RECORD);
        g_status=ctl(L"STATIC",L"Sẵn sàng. `: bắt đầu/dừng · F7: dừng ngay · F8: lấy tọa độ",0,17,378,585,34,ID_STATUS);
        RegisterHotKey(w,HOT_TOGGLE,MOD_NOREPEAT,(UINT)g_hotVk);
        RegisterHotKey(w,HOT_STOP,MOD_NOREPEAT,VK_F7);
        RegisterHotKey(w,HOT_CAPTURE,MOD_NOREPEAT,VK_F8);
        return 0;
    }
    if (msg==WM_COMMAND) {
        int id=(int)(wp&0xffff);
        if (id==ID_START && (wp>>16)==BN_CLICKED) { startClicking(); return 0; }
        if (id==ID_STOP && (wp>>16)==BN_CLICKED) { stopClicking(); status(L"Đang dừng..."); return 0; }
        if (id==ID_PICK && (wp>>16)==BN_CLICKED) { startPick(); return 0; }
        if (id==ID_HOTKEY && (wp>>16)==BN_CLICKED) { openHotDialog(); return 0; }
        if (id==ID_RECORD && (wp>>16)==BN_CLICKED) {
            if (g_recordState==0) startRecording();
            else if (g_recordState==1) stopRecording();
            else if (g_recordState==2) startPlayback();
            return 0;
        }
    }
    if (msg==WM_HOTKEY) {
        int id=(int)wp;
        if (id==HOT_TOGGLE) { startClicking(); return 0; }
        if (id==HOT_STOP) { stopClicking(); status(L"Đã gửi lệnh dừng."); return 0; }
        if (id==HOT_CAPTURE) {
            POINT p; if (GetCursorPos(&p)) { setXY((int)p.x,(int)p.y); check(g_fixed,1); check(g_current,0); status(L"Đã lấy tọa độ chuột hiện tại và chuyển sang tọa độ cố định."); }
            return 0;
        }
    }
    if (msg==WM_APP_PICKED) {
        setXY(g_pickX,g_pickY); check(g_fixed,1); check(g_current,0);
        ShowWindow(g_main,SW_SHOW); SetForegroundWindow(g_main);
        status(L"Đã chọn vị trí click trên màn hình."); return 0;
    }
    if (msg==WM_APP_STATUS) { status((LPCWSTR)lp); return 0; }
    if (msg==WM_APP_FINISHED) {
        closeWorkerHandle(); g_mode=0; InterlockedExchange(&g_running,0); updateRunButtons(0);
        if ((int)wp==2) { g_recordState=2; setText(g_recordButton,L"Phát lại thao tác"); status(L"Đã phát lại xong thao tác chuột."); }
        else { if (g_recordState==3) { g_recordState=2; setText(g_recordButton,L"Phát lại thao tác"); } status(L"Đã dừng click."); }
        return 0;
    }
    if (msg==WM_CLOSE) { DestroyWindow(w); return 0; }
    if (msg==WM_DESTROY) {
        stopClicking(); g_pickPending=0; g_hookKind=0;
        if (g_mouseHook) { UnhookWindowsHookEx(g_mouseHook); g_mouseHook=0; }
        UnregisterHotKey(w,HOT_TOGGLE); UnregisterHotKey(w,HOT_STOP); UnregisterHotKey(w,HOT_CAPTURE);
        if (g_worker) { WaitForSingleObject(g_worker,2000); CloseHandle(g_worker); g_worker=0; }
        PostQuitMessage(0); return 0;
    }
    return DefWindowProcW(w,msg,wp,lp);
}

void WINAPI WinMainCRTStartup(void) {
    g_inst=GetModuleHandleW(0);
    WNDCLASSEXW wc; wc.cbSize=sizeof(WNDCLASSEXW); wc.style=0; wc.lpfnWndProc=mainProc; wc.cbClsExtra=0; wc.cbWndExtra=0; wc.hInstance=g_inst; wc.hIcon=0; wc.hCursor=LoadCursorW(0,IDC_ARROW); wc.hbrBackground=(HBRUSH)6; wc.lpszMenuName=0; wc.lpszClassName=MAIN_CLASS; wc.hIconSm=0;
    if (!RegisterClassExW(&wc)) ExitProcess(1);
    WNDCLASSEXW wh; wh.cbSize=sizeof(WNDCLASSEXW); wh.style=0; wh.lpfnWndProc=hotProc; wh.cbClsExtra=0; wh.cbWndExtra=0; wh.hInstance=g_inst; wh.hIcon=0; wh.hCursor=LoadCursorW(0,IDC_ARROW); wh.hbrBackground=(HBRUSH)6; wh.lpszMenuName=0; wh.lpszClassName=HOT_CLASS; wh.hIconSm=0;
    RegisterClassExW(&wh);
    g_main=CreateWindowExW(0,MAIN_CLASS,L"Nexus AutoClicker",WS_OVERLAPPEDWINDOW & ~0x00050000L,CW_USEDEFAULT,CW_USEDEFAULT,635,465,0,0,g_inst,0);
    if (!g_main) ExitProcess(2);
    ShowWindow(g_main,SW_SHOWNORMAL); UpdateWindow(g_main);
    MSG m; while (GetMessageW(&m,0,0,0)>0) { TranslateMessage(&m); DispatchMessageW(&m); }
    ExitProcess(0);
}
